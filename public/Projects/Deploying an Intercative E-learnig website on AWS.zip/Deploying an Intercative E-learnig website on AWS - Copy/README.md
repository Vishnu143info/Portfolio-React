BrightMind - Interactive E-Learning Platform on AWS

Project Overview
----------------
This project presents the development and deployment of BrightMind, a fully frontend-driven e-learning website hosted on Amazon Web Services (AWS). The platform is designed to provide scalable, cost-effective, and globally accessible online education using static hosting and CDN technologies.

Objectives
----------
- Deploy an interactive e-learning website using AWS S3, CloudFront, and Route 53.
- Use serverless architecture to eliminate backend complexity.
- Ensure global availability and fast content delivery through CDN.
- Provide a responsive user interface using HTML, CSS, JavaScript, and Bootstrap.
- Implement secure access control using AWS IAM policies.

Technologies Used
-----------------
Frontend:
- HTML5
- CSS3
- JavaScript
- Bootstrap 4

AWS Services:
- Amazon S3 (Static website hosting)
- Amazon CloudFront (Content Delivery Network)
- AWS Route 53 (DNS Management)
- AWS IAM (Security and Access Control)
- AWS CLI (Command Line Interface)

Features
--------
- Responsive design for desktop and mobile
- Role-based UI: Admin, Instructor, and Student dashboards
- Course management and progress tracking
- Contact form with integrated map and details
- Real-time performance monitoring and security validation
- Deployed using AWS CloudFront for optimal global access

System Architecture
-------------------
- Frontend: Static website served from S3
- CDN: CloudFront distribution for global caching
- DNS: Route 53 for domain and routing management
- Security: IAM roles and bucket policies for controlled access

Testing Overview
----------------
- Unit Testing for UI components and access control
- Integration Testing across AWS services
- Performance Testing using simulated load
- Security Testing with IAM and S3 public access configurations
- Acceptance Testing with user validation

Future Enhancements
-------------------
- Add secure user authentication with AWS Cognito
- Integrate dynamic backend using AWS Lambda & DynamoDB
- Implement AI-driven course recommendations (via SageMaker)
- Enable real-time discussions and peer forums
- Develop a mobile application using AWS Amplify
- Add gamification (badges, points, leaderboards)
- Support multi-language content and real-time analytics

Screenshots
-----------
Screenshots include:
- AWS console configurations
- S3 bucket and CloudFront setup
- Website interface: Home, About, Contact, Admin, Instructor, and Student pages

Authors
-------
- Naveenprasath S - [613521104021]
- Aswin G - [613521104302]
- Vishnu Prasath A - [613521104312]

Project submitted to Anna University, Government College of Engineering, Dharmapuri (May 2025).

References
----------
- AWS Official Documentation
- Research on cloud-based LMS deployment
- Academic journals on e-learning systems and performance analysis
